THE PARALLEL - BUILD USING GITHUB ACTIONS (PHONE-FRIENDLY)
Minecraft Java 1.20.1 / Forge 47.2.0 / Java 17

1. Extract this ZIP on your phone.
2. In a browser, open https://github.com and sign in/create an account.
3. Create a new repository. Set it Public (simplest for Actions) and name it TheParallel.
4. Upload the CONTENTS of this project folder to the repository root. IMPORTANT: include the hidden .github folder and its workflows/build.yml file. On mobile GitHub upload interface, if hidden folders are difficult to upload, use GitHub's web editor to create .github/workflows/build.yml and paste the workflow file contents.
5. Open the repository's Actions tab. Select “Build The Parallel mod” from the workflow list, tap “Run workflow”, then run it.
6. Wait until the workflow finishes with a green check. Open that completed run, scroll to Artifacts, and download “TheParallel-Forge-1.20.1”.
7. Extract the downloaded artifact ZIP. It contains the mod JAR. Put the JAR in MJ Launcher’s Minecraft 1.20.1 Forge mods folder.

If Actions is disabled, enable it under repository Settings > Actions > General.

This project is source code; the workflow builds the JAR in GitHub's hosted runner.
