package com.example.theparallel;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

public class ModItems {
 public static final DeferredRegister<Item> REGISTER=DeferredRegister.create(ForgeRegistries.ITEMS,TheParallel.MODID);
 public static final RegistryObject<Item> FLASHLIGHT=REGISTER.register("flashlight",()->new FlashlightItem(new Item.Properties().stacksTo(1)));
 public static final RegistryObject<Item> HANDGUN=REGISTER.register("handgun",()->new HandgunItem(new Item.Properties().stacksTo(1)));
 public static void addToCreative(IEventBus bus) {
  bus.addListener(ModItems::creativeTab);
 }
 private static void creativeTab(BuildCreativeModeTabContentsEvent e) {
  if(e.getTabKey()==CreativeModeTabs.TOOLS_AND_UTILITIES) e.accept(FLASHLIGHT);
  if(e.getTabKey()==CreativeModeTabs.COMBAT) e.accept(HANDGUN);
 }
}
