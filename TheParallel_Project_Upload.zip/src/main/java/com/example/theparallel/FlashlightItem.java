package com.example.theparallel;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class FlashlightItem extends Item {
 public FlashlightItem(Properties props){super(props);}
 @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
  ItemStack stack=player.getItemInHand(hand);
  if(!level.isClientSide) {
   // Simple low-cost visibility aid; no custom rendering or light engine updates.
   player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,20*20,0,false,false,true));
   player.getCooldowns().addCooldown(this,100);
  }
  return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
 }
 @Override public UseAnim getUseAnimation(ItemStack stack){return UseAnim.NONE;}
}
