package com.example.theparallel;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.item.UseAnim;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.network.chat.Component;

public class HandgunItem extends Item {
 public HandgunItem(Properties props){super(props);}
 @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
  ItemStack stack=player.getItemInHand(hand);
  if(!level.isClientSide) {
   Vec3 start=player.getEyePosition();
   Vec3 end=start.add(player.getLookAngle().scale(22));
   Entity target=null;
   double best=22.0;
   AABB scan=player.getBoundingBox().expandTowards(player.getLookAngle().scale(22)).inflate(1.0);
   for(Entity e:level.getEntities(player,scan,entity->entity instanceof LivingEntity && entity.isAlive())) {
    AABB bb=e.getBoundingBox().inflate(.25);
    var hit=bb.clip(start,end);
    if(hit.isPresent()) {
     double dist=start.distanceTo(hit.get());
     if(dist<best){best=dist;target=e;}
    }
   }
   if(target instanceof LivingEntity living) {
    living.hurt(player.damageSources().playerAttack(player),8.0F);
    if(target instanceof Zombie z && z.getPersistentData().getBoolean("tp_killer")) {
     player.displayClientMessage(Component.literal("§cThe Parallel was hit!"),true);
    }
   }
   level.playSound(null,player.blockPosition(),SoundEvents.IRON_GOLEM_ATTACK,SoundSource.PLAYERS,.35F,1.6F);
   player.getCooldowns().addCooldown(this,18);
  }
  return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
 }
 @Override public UseAnim getUseAnimation(ItemStack stack){return UseAnim.NONE;}
}
