package com.example.theparallel;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.AABB;
import java.util.List;
import java.util.Random;
import java.time.DayOfWeek;
import java.time.LocalDate;
import net.minecraft.world.item.Items;
import net.minecraft.stats.Stats;

@Mod(TheParallel.MODID)
public class TheParallel {
 public static final String MODID="theparallel";
 private static final Random RNG=new Random();
 public TheParallel() {
  var modBus=FMLJavaModLoadingContext.get().getModEventBus();
  ModItems.REGISTER.register(modBus);
  ModItems.addToCreative(modBus);
  MinecraftForge.EVENT_BUS.register(this);
 }
 @SubscribeEvent
 public void playerTick(TickEvent.PlayerTickEvent e) {
  if(e.phase!=TickEvent.Phase.END || e.player.level().isClientSide) return;
  Player p=e.player; Level level=p.level();
  if(!level.isNight() || p.isCreative() || p.isSpectator() || p.isSleeping()) return;
  long now=level.getGameTime(), next=p.getPersistentData().getLong("tp_next");
  if(now<next) return;
  p.getPersistentData().putLong("tp_next",now+12000L); // 10 minutes
  AABB box=p.getBoundingBox().inflate(48);
  List<Zombie> active=level.getEntitiesOfClass(Zombie.class,box,z->z.isAlive() && z.getPersistentData().getBoolean("tp_killer"));
  if(!active.isEmpty()) return;

  // Unlock only after iron-tier gear or five in-game days of playtime.
  boolean progressed = hasProgress(p);
  if(!progressed) return;
  // Weekend: 50% roll; weekdays: lower 8% roll.
  int chance = isWeekend() ? 50 : 8;
  if(RNG.nextInt(100)>=chance) return;
  double a=RNG.nextDouble()*Math.PI*2, d=16+RNG.nextDouble()*6;
  int x=(int)Math.floor(p.getX()+Math.cos(a)*d), z=(int)Math.floor(p.getZ()+Math.sin(a)*d);
  int y=level.getHeight(Heightmap.Types.MOTION_BLOCKING,x,z);
  Zombie killer=EntityType.ZOMBIE.create(level);
  if(killer==null) return;
  killer.moveTo(x+.5,y,z+.5,RNG.nextFloat()*360,0);
  killer.setCustomName(Component.literal("The Parallel"));
  killer.setCustomNameVisible(false);
  killer.getPersistentData().putBoolean("tp_killer",true);
  killer.setSilent(true);
  killer.setPersistenceRequired();
  killer.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(24);
  killer.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(.30);
  killer.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(7.0);
  killer.setTarget(p);
  level.addFreshEntity(killer);
  p.addEffect(new MobEffectInstance(MobEffects.DARKNESS,30,0,false,false,true));
  p.displayClientMessage(Component.literal("§8Something is hunting you..."),true);
 }

 private static boolean isWeekend() {
  DayOfWeek day=LocalDate.now().getDayOfWeek();
  return day==DayOfWeek.SATURDAY || day==DayOfWeek.SUNDAY;
 }

 private static boolean hasProgress(Player player) {
  // Unlock with at least one iron-tier (or better) armor piece,
  // OR after 5 in-game days of total playtime (120,000 ticks).
  for(var armorStack : player.getArmorSlots()) {
   var item=armorStack.getItem();
   if(item==Items.IRON_HELMET || item==Items.IRON_CHESTPLATE ||
      item==Items.IRON_LEGGINGS || item==Items.IRON_BOOTS ||
      item==Items.DIAMOND_HELMET || item==Items.DIAMOND_CHESTPLATE ||
      item==Items.DIAMOND_LEGGINGS || item==Items.DIAMOND_BOOTS ||
      item==Items.NETHERITE_HELMET || item==Items.NETHERITE_CHESTPLATE ||
      item==Items.NETHERITE_LEGGINGS || item==Items.NETHERITE_BOOTS) return true;
  }
  return player.getStats().getValue(Stats.PLAY_TIME) >= 120000;
 }
}
