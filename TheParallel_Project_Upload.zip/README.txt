THE PARALLEL - LOW END HORROR SOURCE (Forge 1.20.1)
====================================================

This is an updated source project, not a compiled jar.

Features:
- Killer encounter: hostile vanilla zombie marked as The Parallel, hunts player.
- Spawn only at night, 8% roll, attempt cooldown 10 minutes.
- One nearby mod killer at a time.
- Killer uses basic vanilla pathfinding, no custom animation or renderer.
- Flashlight item: right-click grants short Night Vision (20 seconds), cooldown 5 seconds.
  Note: This is a gameplay flashlight approximation; it does not create a real dynamic light.
- Handgun item: right-click hits living entities in a 22-block line, deals 8 damage, cooldown 0.9 seconds.
  No ammo system in this lightweight prototype.
- No shaders, HD textures, particles, or extra dependencies.

Build requirements:
Java 17, Minecraft 1.20.1, Forge 47.x, Gradle.
Run `gradle build`; output jar is in build/libs.

Install:
Copy the compiled jar into the mods folder of the Forge 1.20.1 profile.

Android note:
Forge and Minecraft Java can be demanding on Android. This mod keeps its own overhead small,
but actual compatibility/FPS depends on MJ Launcher version, device, RAM, and graphics settings.
