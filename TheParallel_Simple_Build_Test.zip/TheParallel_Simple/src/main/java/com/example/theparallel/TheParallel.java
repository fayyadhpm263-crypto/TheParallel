package com.example.theparallel;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;

@Mod(TheParallel.MODID)
public class TheParallel {
    public static final String MODID = "theparallel";
    private static final Random RANDOM = new Random();

    public TheParallel() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Player player = event.player;
        Level level = player.level();
        if (level.isClientSide || !level.isNight() || player.isCreative() || player.isSpectator() || player.isSleeping()) return;

        long now = level.getGameTime();
        long next = player.getPersistentData().getLong("theparallel_next_spawn");
        if (now < next) return;
        player.getPersistentData().putLong("theparallel_next_spawn", now + 12000L);

        if (!hasIronArmor(player)) return;
        AABB nearby = player.getBoundingBox().inflate(48.0);
        List<Zombie> hunters = level.getEntitiesOfClass(Zombie.class, nearby,
                zombie -> zombie.isAlive() && zombie.getPersistentData().getBoolean("theparallel_hunter"));
        if (!hunters.isEmpty()) return;

        boolean weekend = LocalDate.now().getDayOfWeek() == DayOfWeek.SATURDAY
                || LocalDate.now().getDayOfWeek() == DayOfWeek.SUNDAY;
        int chance = weekend ? 50 : 8;
        if (RANDOM.nextInt(100) >= chance) return;

        double angle = RANDOM.nextDouble() * Math.PI * 2.0;
        double distance = 18.0 + RANDOM.nextDouble() * 5.0;
        int x = (int)Math.floor(player.getX() + Math.cos(angle) * distance);
        int z = (int)Math.floor(player.getZ() + Math.sin(angle) * distance);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);

        Zombie hunter = EntityType.ZOMBIE.create(level);
        if (hunter == null) return;
        hunter.moveTo(x + 0.5, y, z + 0.5, RANDOM.nextFloat() * 360.0F, 0.0F);
        hunter.setCustomName(Component.literal("The Parallel"));
        hunter.setCustomNameVisible(false);
        hunter.getPersistentData().putBoolean("theparallel_hunter", true);
        hunter.setSilent(true);
        hunter.setPersistenceRequired();
        hunter.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(28.0);
        hunter.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.30);
        hunter.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(7.0);
        hunter.setTarget(player);
        level.addFreshEntity(hunter);
        player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 40, 0, false, false, true));
        player.displayClientMessage(Component.literal("Something is hunting you..."), true);
    }

    private static boolean hasIronArmor(Player player) {
        for (var stack : player.getArmorSlots()) {
            if (stack.is(Items.IRON_HELMET) || stack.is(Items.IRON_CHESTPLATE)
                    || stack.is(Items.IRON_LEGGINGS) || stack.is(Items.IRON_BOOTS)
                    || stack.is(Items.DIAMOND_HELMET) || stack.is(Items.DIAMOND_CHESTPLATE)
                    || stack.is(Items.DIAMOND_LEGGINGS) || stack.is(Items.DIAMOND_BOOTS)
                    || stack.is(Items.NETHERITE_HELMET) || stack.is(Items.NETHERITE_CHESTPLATE)
                    || stack.is(Items.NETHERITE_LEGGINGS) || stack.is(Items.NETHERITE_BOOTS)) {
                return true;
            }
        }
        return false;
    }
}
