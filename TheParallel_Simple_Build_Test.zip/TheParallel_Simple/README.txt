The Parallel - simplified build test
Minecraft Forge 1.20.1, Forge 47.2.0, Java 17.

Features:
- Lightweight vanilla zombie hunter (no custom entity renderer/model).
- Hunter is unlocked after wearing at least one iron-or-better armor piece.
- Spawns only at night, with a 10-minute cooldown.
- Weekend spawn chance 50%; weekday chance 8%.
- Silent hunter, increased follow range, darkness message/effect.

This is a first compile-test version. Flashlight and handgun are intentionally left out until the base mod builds successfully.
